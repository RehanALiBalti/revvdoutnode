const axios = require('axios');
const qs = require('qs');

exports.handler = async (event) => {
  event.response.autoConfirmUser = true;
  event.response.autoVerifyEmail = true;
  console.log('Received event:', JSON.stringify(event, null, 2));

  const userAttributes = event.request.userAttributes;
  console.log(userAttributes);

  const sub = userAttributes.sub;
  if (sub === undefined) {
    return event;
  }

  const email = userAttributes.email;
  let nickname = userAttributes.nickname;
  if (nickname === undefined) {
    nickname = userAttributes.name;
  }

  var data = qs.stringify({
    'sub': sub,
    'email': email,
    'nickname': nickname
  });

  var config = {
    method: 'post',
 //   url: 'http://52.59.240.119/api/users/userexistsbysub',
    url: 'https://king-prawn-app-3rw3o.ondigitalocean.app/api/users/userexistsbysub',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    data: data
  };

  try {
    const response = await axios(config);
    console.log('Response data:', JSON.stringify(response.data));

    // Process the response data if necessary
    // Example: if user doesn't exist, add custom logic

  } catch (error) {
    console.error('Error during axios request:', error);
    // If you want to handle the error and still allow the user creation to proceed
    // you should return the `event` object here
  }

  return event; // Ensure that the event is returned after the axios call
};
